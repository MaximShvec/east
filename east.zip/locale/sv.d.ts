declare module 'air-datepicker/locale/sv' {
    import {AirDatepickerLocale} from 'air-datepicker';
    const sv: AirDatepickerLocale;

    export default sv;
}
