declare module 'air-datepicker/locale/ar' {
    import {AirDatepickerLocale} from 'air-datepicker';
    const ar: AirDatepickerLocale;

    export default ar;
}
