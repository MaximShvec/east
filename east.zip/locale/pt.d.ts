declare module 'air-datepicker/locale/pt' {
    import {AirDatepickerLocale} from 'air-datepicker';
    const pt: AirDatepickerLocale;

    export default pt;
}
