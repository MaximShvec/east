declare module 'air-datepicker/locale/id' {
    import {AirDatepickerLocale} from 'air-datepicker';
    const id: AirDatepickerLocale;

    export default id;
}
