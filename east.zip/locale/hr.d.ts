declare module 'air-datepicker/locale/hr' {
    import {AirDatepickerLocale} from 'air-datepicker';
    const hr: AirDatepickerLocale;

    export default hr;
}
