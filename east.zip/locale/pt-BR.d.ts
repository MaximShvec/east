declare module 'air-datepicker/locale/pt-BR' {
    import {AirDatepickerLocale} from 'air-datepicker';
    const pt-BR: AirDatepickerLocale;

    export default pt-BR;
}
