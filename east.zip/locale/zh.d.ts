declare module 'air-datepicker/locale/zh' {
    import {AirDatepickerLocale} from 'air-datepicker';
    const zh: AirDatepickerLocale;

    export default zh;
}
