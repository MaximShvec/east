declare module 'air-datepicker/locale/hu' {
    import {AirDatepickerLocale} from 'air-datepicker';
    const hu: AirDatepickerLocale;

    export default hu;
}
