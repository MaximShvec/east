declare module 'air-datepicker/locale/uk' {
    import {AirDatepickerLocale} from 'air-datepicker';
    const uk: AirDatepickerLocale;

    export default uk;
}
