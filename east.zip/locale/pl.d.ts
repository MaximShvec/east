declare module 'air-datepicker/locale/pl' {
    import {AirDatepickerLocale} from 'air-datepicker';
    const pl: AirDatepickerLocale;

    export default pl;
}
