declare module 'air-datepicker/locale/tr' {
    import {AirDatepickerLocale} from 'air-datepicker';
    const tr: AirDatepickerLocale;

    export default tr;
}
